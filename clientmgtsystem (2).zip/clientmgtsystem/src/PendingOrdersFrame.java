import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;


public class PendingOrdersFrame extends JFrame {
    private JTextField orderIdField;
    private JTextField productNameField;
    private JTextField quantityField;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton viewButton;
    private JButton markAsCompleteButton;
    private JButton viewCompletedButton;
    private JButton viewProductsButton;
    private JButton downloadCompletedOrdersButton; // New button for downloading completed orders
    private Connection connection;
    private JTable table;
    private DefaultTableModel tableModel;

 public PendingOrdersFrame(Connection connection) {
        this.connection = connection;
        setTitle("Pending Orders Management");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 2));  // Increase grid rows to accommodate the heading

        // Add heading label
        JLabel headingLabel = new JLabel("Pending Orders");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Customize font
        headingLabel.setHorizontalAlignment(JLabel.CENTER);
        panel.add(headingLabel);
        panel.add(new JLabel()); 
        orderIdField = new JTextField(15);
        productNameField = new JTextField(15);
        quantityField = new JTextField(15);

        addButton = new JButton("Add Order");
        editButton = new JButton("Edit Order");
        deleteButton = new JButton("Delete Order");
        viewButton = new JButton("View Orders");
        markAsCompleteButton = new JButton("Mark as Complete");
        viewCompletedButton = new JButton("View Completed Orders");
        viewProductsButton = new JButton("View Available Products");
        downloadCompletedOrdersButton = new JButton("Download Completed Orders"); // New button
        panel.add(new JLabel("Order ID:"));
        panel.add(orderIdField);
        panel.add(new JLabel("Product Name:"));
        panel.add(productNameField);
        panel.add(new JLabel("Quantity:"));
        panel.add(quantityField);
        panel.add(addButton);
        panel.add(editButton);
        panel.add(deleteButton);
        panel.add(viewButton);
        panel.add(markAsCompleteButton);
        panel.add(viewCompletedButton);
        panel.add(viewProductsButton);
        panel.add(downloadCompletedOrdersButton);
        // Create a table to display orders
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Order ID");
        tableModel.addColumn("Product Name");
        tableModel.addColumn("Quantity");
        tableModel.addColumn("Status");
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the table to the frame
        add(scrollPane, BorderLayout.CENTER);
              customizeButton(addButton);
        customizeButton(editButton);
        customizeButton(deleteButton);
        customizeButton(viewButton);
        customizeButton(markAsCompleteButton);
        customizeButton(viewCompletedButton);
        customizeButton(viewProductsButton);
        customizeButton(downloadCompletedOrdersButton);


        // Attach action listeners for buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addOrder();
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editOrder();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteOrder();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewOrders();
            }
        });

        markAsCompleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                markAsComplete();
            }
        });

        viewCompletedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewCompletedOrders();
            }
        });

        viewProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewAvailableProducts();
            }
        });
 downloadCompletedOrdersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                downloadCompletedOrdersToCSV();
            }
 });
        add(panel, BorderLayout.NORTH);
    }
 
  private void customizeButton(JButton button) {
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
    }
private void downloadCompletedOrdersToCSV() {
        try {
            // Create a FileWriter to write to a CSV file
            FileWriter csvWriter = new FileWriter("completed_orders.csv");

            // Write the CSV header
            csvWriter.append("Order ID,Product Name,Quantity,Status\n");

            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM orders WHERE status = 'Complete'"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int orderId = resultSet.getInt("order_id");
                String productName = resultSet.getString("product_name");
                int quantity = resultSet.getInt("quantity");
                String status = resultSet.getString("status");

                // Write order data to the CSV file
                csvWriter.append(orderId + "," + productName + "," + quantity + "," + status + "\n");
            }

            csvWriter.flush();
            csvWriter.close();

            JOptionPane.showMessageDialog(this, "Completed orders downloaded to 'completed_orders.csv' successfully.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error creating or writing to the CSV file: " + ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }
    private void addOrder() {
        String productName = productNameField.getText();
        String quantityStr = quantityField.getText();

        try {
            int quantity = Integer.parseInt(quantityStr);

            // Check if any of the fields is empty
            if (productName.isEmpty() || quantityStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
                return; // Exit the method without adding an order
            }

            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO orders (product_name, quantity, status) VALUES (?, ?, 'Pending')"
            );
            preparedStatement.setString(1, productName);
            preparedStatement.setInt(2, quantity);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Order added successfully.");
                clearFields();
                displayOrders(); // Refresh the order list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add order.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numbers.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void editOrder() {
        String orderIdStr = orderIdField.getText();
        String productName = productNameField.getText();
        String quantityStr = quantityField.getText();

        try {
            int orderId = Integer.parseInt(orderIdStr);
            int quantity = Integer.parseInt(quantityStr);

            // Check if any of the fields is empty
            if (orderIdStr.isEmpty() || productName.isEmpty() || quantityStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
                return; // Exit the method without editing an order
            }

            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE orders SET product_name = ?, quantity = ? WHERE order_id = ?"
            );
            preparedStatement.setString(1, productName);
            preparedStatement.setInt(2, quantity);
            preparedStatement.setInt(3, orderId);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Order updated successfully.");
                clearFields();
                displayOrders(); // Refresh the order list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update order.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid order ID or quantity. Please enter valid numbers.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void deleteOrder() {
        String orderIdStr = orderIdField.getText();

        try {
            int orderId = Integer.parseInt(orderIdStr);

            // Check if the order ID field is empty
            if (orderIdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter the Order ID.");
                return; // Exit the method without deleting an order
            }

            PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM orders WHERE order_id = ?"
            );
            preparedStatement.setInt(1, orderId);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Order deleted successfully.");
                clearFields();
                displayOrders(); // Refresh the order list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete order. Please enter a valid Order ID.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid order ID. Please enter a valid number.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void viewOrders() {
        displayOrders();
    }

    private void markAsComplete() {
        String orderIdStr = orderIdField.getText();

        try {
            int orderId = Integer.parseInt(orderIdStr);

            // Check if the order ID field is empty
            if (orderIdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter the Order ID.");
                return; // Exit the method without marking an order as complete
            }

            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE orders SET status = 'Complete' WHERE order_id = ?"
            );
            preparedStatement.setInt(1, orderId);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Order marked as complete.");
                clearFields();
                displayOrders(); // Refresh the order list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to mark order as complete. Please enter a valid Order ID.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid order ID. Please enter a valid number.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void viewCompletedOrders() {
        displayCompletedOrders();
    }

    private void viewAvailableProducts() {
        displayAvailableProducts();
    }

    private void clearFields() {
        orderIdField.setText("");
        productNameField.setText("");
        quantityField.setText("");
    }

    private void displayOrders() {
        // Clear the table
        tableModel.setRowCount(0);

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM orders WHERE status = 'Pending'"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int orderId = resultSet.getInt("order_id");
                String productName = resultSet.getString("product_name");
                int quantity = resultSet.getInt("quantity");
                String status = resultSet.getString("status");

                // Add the order information to the table
                tableModel.addRow(new Object[]{orderId, productName, quantity, status});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void displayCompletedOrders() {
        // Clear the table
        tableModel.setRowCount(0);

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM orders WHERE status = 'Complete'"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int orderId = resultSet.getInt("order_id");
                String productName = resultSet.getString("product_name");
                int quantity = resultSet.getInt("quantity");
                String status = resultSet.getString("status");

                // Add the order information to the table
                tableModel.addRow(new Object[]{orderId, productName, quantity, status});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void displayAvailableProducts() {
        // Clear the table
        tableModel.setRowCount(0);

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM products"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String productName = resultSet.getString("name");
                String productPrice = resultSet.getString("price");
                String productDescription = resultSet.getString("description");

                // Add the product information to the table
                tableModel.addRow(new Object[]{productName, productPrice, productDescription});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        // Add the main method to test the PendingOrdersFrame class
        final Connection[] connection = {null}; // Declare as a final array

        try {
            // Set up database connection (replace with your database URL, username, and password)
            String url = "jdbc:mysql://127.0.0.1:3306/clientmgtsystem";
            String user = "your_username";
            String dbPassword = "your_password";
            connection[0] = DriverManager.getConnection(url, user, dbPassword);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database connection failed: " + ex.getMessage());
            System.exit(1);
        }

        // Check if the connection is not null before creating the frame
        if (connection[0] != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new PendingOrdersFrame(connection[0]).setVisible(true);
                }
            });
        } else {
            // Handle the case where the connection is null (e.g., display an error message)
            JOptionPane.showMessageDialog(null, "Database connection is null. Exiting.");
            System.exit(1);
        }
    }
}
