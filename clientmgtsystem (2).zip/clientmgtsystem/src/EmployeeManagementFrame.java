import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
import java.util.Vector;

public class EmployeeManagementFrame extends JFrame {
    private JTextField nameField;
    private JTextField contactNumberField;
    private JTextField contactEmailField;
    private JButton addButton;
    private JButton viewButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton clearButton;
    private JButton findButton;
    private JButton updateButton;
    private Connection connection;

    public EmployeeManagementFrame(Connection connection) {
        this.connection = connection;
        setTitle("Employee Management");
        setSize(600, 500); // Increased width and height to accommodate the logo and heading
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Set the background color of the frame
        getContentPane().setBackground(Color.WHITE);

        // Create a panel for the heading and logo
        JPanel headingPanel = new JPanel(new BorderLayout());
        headingPanel.setBackground(Color.BLACK);

        // Create a label for the circular logo (replace "logo.png" with your logo file path)
        JLabel logoLabel = new JLabel(new ImageIcon("logo.png"));
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headingPanel.add(logoLabel, BorderLayout.CENTER);

        // Create a label for the heading
        JLabel titleLabel = new JLabel("Employee Management");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headingPanel.add(titleLabel, BorderLayout.SOUTH);

        // Create a panel for the text fields and buttons
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.setBackground(Color.WHITE);

        nameField = createStyledTextField("Name");
        contactNumberField = createStyledTextField("Contact Number");
        contactEmailField = createStyledTextField("Contact Email");

        addButton = createStyledButton("Add");
        viewButton = createStyledButton("View");
        editButton = createStyledButton("Edit");
        deleteButton = createStyledButton("Delete");
        clearButton = createStyledButton("Clear");
        findButton = createStyledButton("Find");
        updateButton = createStyledButton("Update");

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Contact Number:"));
        formPanel.add(contactNumberField);
        formPanel.add(new JLabel("Contact Email:"));
        formPanel.add(contactEmailField);
        formPanel.add(addButton);
        formPanel.add(editButton);
        formPanel.add(deleteButton);
        formPanel.add(viewButton);
        formPanel.add(clearButton);
        formPanel.add(findButton);
        formPanel.add(updateButton);

        // Attach action listeners for buttons (unchanged)
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addEmployee();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewEmployee();
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editEmployee();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteEmployee();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findEmployee();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateEmployee();
            }
        });

        // Add the heading and form panels to the frame
        add(headingPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
    }

    // Create a styled text field
    private JTextField createStyledTextField(String placeholder) {
        JTextField textField = new JTextField(15);
        textField.setForeground(Color.BLACK);
        textField.setBackground(Color.WHITE);
        textField.setFont(new Font("Arial", Font.PLAIN, 16));
        textField.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        textField.setCaretColor(Color.BLACK);
        textField.setMargin(new Insets(5, 5, 5, 5));
        textField.setHorizontalAlignment(JTextField.LEFT);
        textField.setToolTipText(placeholder);
        return textField;
    }

    // Create a styled button
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setForeground(Color.WHITE);
        button.setBackground(Color.BLACK);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        return button;
    }
    private void addEmployee() {
        String name = nameField.getText();
        String contactNumber = contactNumberField.getText();
        String contactEmail = contactEmailField.getText();

        // Check if any of the fields is empty
        if (name.isEmpty() || contactNumber.isEmpty() || contactEmail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return; // Exit the method without adding an employee
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO employees (name, contact_number, contact_email) VALUES (?, ?, ?)"
            );
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, contactNumber);
            preparedStatement.setString(3, contactEmail);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Employee added successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add employee.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void viewEmployee() {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM employees"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            // Create a JTable to display the employee data
            Vector<Vector<String>> data = new Vector<Vector<String>>();
            Vector<String> columnNames = new Vector<String>();

            columnNames.add("Name");
            columnNames.add("Contact Number");
            columnNames.add("Contact Email");

            while (resultSet.next()) {
                Vector<String> row = new Vector<String>();
                row.add(resultSet.getString("name"));
                row.add(resultSet.getString("contact_number"));
                row.add(resultSet.getString("contact_email"));
                data.add(row);
            }

            JTable table = new JTable(data, columnNames);
            JScrollPane scrollPane = new JScrollPane(table);

            JFrame viewFrame = new JFrame("View Employees");
            viewFrame.getContentPane().add(scrollPane);
            viewFrame.setSize(600, 400);
            viewFrame.setVisible(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void editEmployee() {
        String name = nameField.getText();
        String contactNumber = contactNumberField.getText();
        String contactEmail = contactEmailField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE employees SET contact_number = ?, contact_email = ? WHERE name = ?"
            );
            preparedStatement.setString(1, contactNumber);
            preparedStatement.setString(2, contactEmail);
            preparedStatement.setString(3, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Employee updated successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update employee.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void deleteEmployee() {
        String name = nameField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM employees WHERE name = ?"
            );
            preparedStatement.setString(1, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Employee deleted successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete employee.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        nameField.setText("");
        contactNumberField.setText("");
        contactEmailField.setText("");
    }

    private void findEmployee() {
        String name = nameField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM employees WHERE name LIKE ?"
            );
            preparedStatement.setString(1, "%" + name + "%");

            ResultSet resultSet = preparedStatement.executeQuery();

            // Process the resultSet and display the results
            // You can use a JTable or other UI component to display the results to the user.
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void updateEmployee() {
        String name = nameField.getText();
        String contactNumber = contactNumberField.getText();
        String contactEmail = contactEmailField.getText();

        // Check if any of the fields is empty
        if (name.isEmpty() || contactNumber.isEmpty() || contactEmail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return; // Exit the method without updating the employee
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE employees SET contact_number = ?, contact_email = ? WHERE name = ?"
            );
            preparedStatement.setString(1, contactNumber);
            preparedStatement.setString(2, contactEmail);
            preparedStatement.setString(3, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Employee updated successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update employee.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }


  public static void main(String[] args) {
        final Connection[] connection = {null};

        try {
            // Set up database connection (replace with your database URL, username, and password)
            String url = "jdbc:mysql://127.0.0.1:3306/clientmgtsystem";
            String user = "hanzalah";
            String dbPassword = "12345678";
            connection[0] = DriverManager.getConnection(url, user, dbPassword);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database connection failed: " + ex.getMessage());
            System.exit(1);
        }

        if (connection[0] != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new EmployeeManagementFrame(connection[0]).setVisible(true);
                }
            });
        } else {
            JOptionPane.showMessageDialog(null, "Database connection is null. Exiting.");
            System.exit(1);
        }
    }
}