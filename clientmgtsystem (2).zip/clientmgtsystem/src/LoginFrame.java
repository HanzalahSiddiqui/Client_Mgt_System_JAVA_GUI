import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signupButton;

    public LoginFrame() {
        setTitle("Login");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with a custom layout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create a circular logo using a JLabel
        JLabel logoLabel = new JLabel("Logo", JLabel.CENTER);
        logoLabel.setForeground(Color.WHITE);
        logoLabel.setFont(new Font("Arial", Font.BOLD, 20));
        logoLabel.setOpaque(true);
        logoLabel.setBackground(Color.BLACK);
        logoLabel.setPreferredSize(new Dimension(100, 100));
        logoLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create a panel for the logo
        JPanel logoPanel = new JPanel(new BorderLayout());
        logoPanel.add(logoLabel, BorderLayout.CENTER);

        mainPanel.add(logoPanel, BorderLayout.NORTH);

        JPanel credentialsPanel = new JPanel();
        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        loginButton = new JButton("Login");
        signupButton = new JButton("Signup");

        loginButton.setBackground(Color.BLACK);
        loginButton.setForeground(Color.WHITE);

        signupButton.setBackground(Color.BLACK);
        signupButton.setForeground(Color.WHITE);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (isValidUser(username, password)) {
                    dispose();
                    openDashboard();
                } else {
                    JOptionPane.showMessageDialog(LoginFrame.this, "Login failed. Please try again.");
                }
            }
        });

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                openSignupFrame();
            }
        });

        credentialsPanel.add(new JLabel("Username:"));
        credentialsPanel.add(usernameField);
        credentialsPanel.add(new JLabel(""));
        credentialsPanel.add(new JLabel("Password:"));
        credentialsPanel.add(passwordField);
        credentialsPanel.add(loginButton);
        credentialsPanel.add(signupButton);

        mainPanel.add(credentialsPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);
    }

    public boolean isValidUser(String username, String password) {
        try {
            Connection connection = DatabaseManager.getConnection();

            if (connection != null) {
                String query = "SELECT * FROM users WHERE username = ? AND password = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, username);
                statement.setString(2, password);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    resultSet.close();
                    statement.close();
                    connection.close();
                    return true;
                } else {
                    resultSet.close();
                    statement.close();
                    connection.close();
                    return false;
                }
            } else {
                JOptionPane.showMessageDialog(this, "Database connection failed.");
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            return false;
        }
    }

    private void openDashboard() {
        Connection connection;
        try {
            connection = DatabaseManager.getConnection();
            if (connection != null) {
                DashboardFrame dashboardFrame = new DashboardFrame(connection);
                dashboardFrame.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Database connection failed.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void openSignupFrame() {
        Connection connection;
        try {
            connection = DatabaseManager.getConnection();
            if (connection != null) {
                SignupFrame signupFrame = new SignupFrame(connection);
                signupFrame.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Database connection failed.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginFrame();
            }
        });
    }
}
