
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;

public class ProductManagementFrame extends JFrame {
    private JTextField nameField;
    private JTextField priceField;
    private JTextField quantityField; // Added quantity field
    private JTextField descriptionField;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton clearButton;
    private Connection connection;
    private JTable table;
    private DefaultTableModel tableModel;

    public ProductManagementFrame(Connection connection) {
        this.connection = connection;
        setTitle("Product Management");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2)); // Adjusted layout to accommodate the new quantity field

        nameField = new JTextField(15);
        priceField = new JTextField(15);
        quantityField = new JTextField(15); // Added quantity field
        descriptionField = new JTextField(15);

        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear");


        editButton.setBackground(Color.BLACK);
        addButton.setBackground(Color.BLACK);
        deleteButton.setBackground(Color.BLACK);
        clearButton.setBackground(Color.BLACK);

        editButton.setForeground(Color.WHITE);
        addButton.setForeground(Color.WHITE);
        deleteButton.setForeground(Color.WHITE);
        clearButton.setForeground(Color.WHITE);



        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Price:"));
        panel.add(priceField);
        panel.add(new JLabel("Quantity:"));
        panel.add(quantityField); // Added quantity field
        panel.add(new JLabel("Description:"));
        panel.add(descriptionField);
        panel.add(addButton);
        panel.add(editButton);
        panel.add(deleteButton);
        panel.add(clearButton);

        // Create a table to display products
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Name");
        tableModel.addColumn("Price");
        tableModel.addColumn("Quantity");
        tableModel.addColumn("Description");
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the table to the frame
        add(scrollPane, BorderLayout.CENTER);

        // Attach action listeners for buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProduct();
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editProduct();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteProduct();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        // Display products when the frame is created
        displayProducts();

        add(panel, BorderLayout.NORTH);
    }

    private void addProduct() {
        String name = nameField.getText();
        String price = priceField.getText();
        String quantity = quantityField.getText(); // Added quantity field
        String description = descriptionField.getText();

        // Check if any of the fields is empty
        if (name.isEmpty() || price.isEmpty() || quantity.isEmpty() || description.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return; // Exit the method without adding a product
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO products (name, price, quantity, description) VALUES (?, ?, ?, ?)"
            );
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, price);
            preparedStatement.setString(3, quantity);
            preparedStatement.setString(4, description);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Product added successfully.");
                clearFields();
                displayProducts(); // Refresh the product list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add product.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void editProduct() {
        String name = nameField.getText();
        String price = priceField.getText();
        String quantity = quantityField.getText(); // Added quantity field
        String description = descriptionField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE products SET price = ?, quantity = ?, description = ? WHERE name = ?"
            );
            preparedStatement.setString(1, price);
            preparedStatement.setString(2, quantity);
            preparedStatement.setString(3, description);
            preparedStatement.setString(4, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Product updated successfully.");
                clearFields();
                displayProducts(); // Refresh the product list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update product.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Fill all the relevant fields!");
        }
    }

    private void deleteProduct() {
        String name = nameField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM products WHERE name = ?"
            );
            preparedStatement.setString(1, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Product deleted successfully.");
                clearFields();
                displayProducts(); // Refresh the product list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete product.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        nameField.setText("");
        priceField.setText("");
        quantityField.setText("");
        descriptionField.setText("");
    }

    private void displayProducts() {
        // Clear the table
        tableModel.setRowCount(0);

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM products"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String productName = resultSet.getString("name");
                String productPrice = resultSet.getString("price");
                String productQuantity = resultSet.getString("quantity"); // Added quantity field
                String productDescription = resultSet.getString("description");

                // Add the product information to the table
                tableModel.addRow(new String[]{productName, productPrice, productQuantity, productDescription});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        final Connection[] connection = {null}; // Declare as a final array

        try {
            // Set up database connection (replace with your database URL, username, and password)
            String url = "jdbc:mysql://127.0.0.1:3306/clientmgtsystem";
            String user = "hanzalah";
            String dbPassword = "12345678";
            connection[0] = DriverManager.getConnection(url, user, dbPassword);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database connection failed: " + ex.getMessage());
            System.exit(1);
        }

        // Check if the connection is not null before creating the frame
        if (connection[0] != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new ProductManagementFrame(connection[0]).setVisible(true);
                }
            });
        } else {
            // Handle the case where the connection is null (e.g., display an error message)
            JOptionPane.showMessageDialog(null, "Database connection is null. Exiting.");
            System.exit(1);
        }
    }
}
