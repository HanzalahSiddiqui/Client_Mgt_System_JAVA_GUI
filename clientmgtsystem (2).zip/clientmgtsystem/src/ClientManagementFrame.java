import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
import java.util.Vector;

public class ClientManagementFrame extends JFrame {
    private JTextField nameField;
    private JTextField contactNumberField;
    private JTextField contactEmailField;
    private JButton addButton;
    private JButton viewButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton clearButton;
    private JButton findButton;
    private JButton updateButton;
    private Connection connection;

    public ClientManagementFrame(Connection connection) {
        this.connection = connection;
        setTitle("Client Management");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1));

        nameField = new JTextField(15);
        contactNumberField = new JTextField(15);
        contactEmailField = new JTextField(15);

        addButton = new JButton("Add");
        viewButton = new JButton("View");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear");
        findButton = new JButton("Find");
        updateButton = new JButton("Update");  addButton = new JButton("Add");

        addButton.setBackground(Color.BLACK);

        viewButton.setBackground(Color.BLACK);
        editButton.setBackground(Color.BLACK);
        deleteButton.setBackground(Color.BLACK);
        clearButton.setBackground(Color.BLACK);
        findButton.setBackground(Color.BLACK);
        updateButton.setBackground(Color.BLACK);        viewButton.setBackground(Color.BLACK);
        editButton.setForeground(Color.WHITE);
        addButton.setForeground(Color.WHITE);
        deleteButton.setForeground(Color.WHITE);
        clearButton.setForeground(Color.WHITE);
        findButton.setForeground(Color.WHITE);
        viewButton.setForeground(Color.WHITE);
        updateButton.setForeground(Color.WHITE);


        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Contact Number:"));
        panel.add(contactNumberField);
        panel.add(new JLabel("Contact Email:"));
        panel.add(contactEmailField);
        panel.add(addButton);
        panel.add(viewButton);
        panel.add(editButton);
        panel.add(deleteButton);
        panel.add(clearButton);
        panel.add(findButton);
        panel.add(updateButton);

        // Attach action listeners for buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addClient();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewClient();
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editClient();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteClient();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findClient();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateClient();
            }
        });

        add(panel);
    }

    private void addClient() {
        String name = nameField.getText();
        String contactNumber = contactNumberField.getText();
        String contactEmail = contactEmailField.getText();

        // Check if any of the fields is empty
        if (name.isEmpty() || contactNumber.isEmpty() || contactEmail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return; // Exit the method without adding a client
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO clients (name, contact_number, contact_email) VALUES (?, ?, ?)"
            );
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, contactNumber);
            preparedStatement.setString(3, contactEmail);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Client added successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add client.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void viewClient() {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM clients"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            // Create a JTable to display the client data
            Vector<Vector<String>> data = new Vector<Vector<String>>();
            Vector<String> columnNames = new Vector<String>();

            columnNames.add("Name");
            columnNames.add("Contact Number");
            columnNames.add("Contact Email");

            while (resultSet.next()) {
                Vector<String> row = new Vector<String>();
                row.add(resultSet.getString("name"));
                row.add(resultSet.getString("contact_number"));
                row.add(resultSet.getString("contact_email"));
                data.add(row);
            }

            JTable table = new JTable(data, columnNames);
            JScrollPane scrollPane = new JScrollPane(table);

            JFrame viewFrame = new JFrame("View Clients");
            viewFrame.getContentPane().add(scrollPane);
            viewFrame.setSize(600, 400);
            viewFrame.setVisible(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void editClient() {
        String name = nameField.getText();
        String contactNumber = contactNumberField.getText();
        String contactEmail = contactEmailField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE clients SET contact_number = ?, contact_email = ? WHERE name = ?"
            );
            preparedStatement.setString(1, contactNumber);
            preparedStatement.setString(2, contactEmail);
            preparedStatement.setString(3, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Client updated successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update client.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void deleteClient() {
        String name = nameField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM clients WHERE name = ?"
            );
            preparedStatement.setString(1, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Client deleted successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete client.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        nameField.setText("");
        contactNumberField.setText("");
        contactEmailField.setText("");
    }

    private void findClient() {
        String name = nameField.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM clients WHERE name LIKE ?"
            );
            preparedStatement.setString(1, "%" + name + "%");

            ResultSet resultSet = preparedStatement.executeQuery();

            // Process the resultSet and display the results
            StringBuilder resultText = new StringBuilder("Matching Clients:\n");

            while (resultSet.next()) {
                String clientName = resultSet.getString("name");
                String contactNumber = resultSet.getString("contact_number");
                String contactEmail = resultSet.getString("contact_email");

                // Append the client information to the resultText
                resultText.append("Name: ").append(clientName).append("\n");
                resultText.append("Contact Number: ").append(contactNumber).append("\n");
                resultText.append("Contact Email: ").append(contactEmail).append("\n");
                resultText.append("--------------------------\n");
            }

            if (resultText.length() > 20) {
                // If there are matching clients, display the results
                JOptionPane.showMessageDialog(this, resultText.toString());
            } else {
                JOptionPane.showMessageDialog(this, "No matching clients found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void updateClient() {
        String name = nameField.getText();
        String contactNumber = contactNumberField.getText();
        String contactEmail = contactEmailField.getText();

        // Check if any of the fields is empty
        if (name.isEmpty() || contactNumber.isEmpty() || contactEmail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return; // Exit the method without updating the client
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE clients SET contact_number = ?, contact_email = ? WHERE name = ?"
            );
            preparedStatement.setString(1, contactNumber);
            preparedStatement.setString(2, contactEmail);
            preparedStatement.setString(3, name);

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Client updated successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update client.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }


    public static void main(String[] args) {
        final Connection[] connection = {null}; // Declare as a final array

        try {
            // Set up database connection (replace with your database URL, username, and password)
            String url = "jdbc:mysql://127.0.0.1:3306/clientmgtsystem";
            String user = "hanzalah";
            String dbPassword = "12345678";
            connection[0] = DriverManager.getConnection(url, user, dbPassword);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database connection failed: " + ex.getMessage());
            System.exit(1);
        }

        // Check if the connection is not null before creating the frame
        if (connection[0] != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new ClientManagementFrame(connection[0]).setVisible(true);
                }
            });
        } else {
            // Handle the case where the connection is null (e.g., display an error message)
            JOptionPane.showMessageDialog(null, "Database connection is null. Exiting.");
            System.exit(1);
        }
    }
}
