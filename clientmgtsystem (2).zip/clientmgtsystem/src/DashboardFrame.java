import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DashboardFrame extends JFrame {
    private JButton employeeButton;
    private JButton clientButton;
    private JButton productsButton;
    private JButton pendingOrdersButton;
    private JButton downloadOrderHistoryButton;
    private final Connection connection; // Declare as final

    public DashboardFrame(final Connection connection) {
        this.connection = connection; // Initialize the connection field
        setTitle("Dashboard");
        setSize(400, 400); // Increased height to accommodate the logo
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout()); // Use BorderLayout for better organization

        // Set the background color of the frame
        getContentPane().setBackground(Color.WHITE);

        // Create a panel for the heading and logo
        JPanel headingPanel = new JPanel(new BorderLayout());
        headingPanel.setBackground(Color.BLACK);

        // Create a label for the circular logo

        // Create a label for the dashboard title
        JLabel titleLabel = new JLabel("Dashboard");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Set a larger, bold font
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center align the title
        headingPanel.add(titleLabel, BorderLayout.SOUTH);

                JLabel logoLabel = new JLabel(new ImageIcon("logo.png")); // Replace "logo.png" with your logo file path
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center align the logo
        headingPanel.add(logoLabel, BorderLayout.CENTER);

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel(new GridLayout(0, 1, 10, 10)); // GridLayout for organized buttons
        buttonPanel.setBackground(Color.WHITE); // Set the background color of the panel

        // Create styled buttons with smaller size
        employeeButton = createStyledButton("Employee");
        clientButton = createStyledButton("Client");
        productsButton = createStyledButton("Products");
        pendingOrdersButton = createStyledButton("Pending Orders");
        downloadOrderHistoryButton = createStyledButton("Download Order History");

        // Add buttons to the button panel
        buttonPanel.add(employeeButton);
        buttonPanel.add(clientButton);
        buttonPanel.add(productsButton);
        buttonPanel.add(pendingOrdersButton);
        buttonPanel.add(downloadOrderHistoryButton);

        // Add the heading and button panels to the frame
        add(headingPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);

        // Add action listeners for buttons (unchanged)
        employeeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EmployeeManagementFrame employeeFrame = new EmployeeManagementFrame(connection);
                employeeFrame.setVisible(true);
            }
        });

        clientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ClientManagementFrame clientFrame = new ClientManagementFrame(connection);
                clientFrame.setVisible(true);
            }
        });

        productsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProductManagementFrame productFrame = new ProductManagementFrame(connection);
                productFrame.setVisible(true);
            }
        });

        pendingOrdersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PendingOrdersFrame pendingOrdersFrame = new PendingOrdersFrame(connection);
                pendingOrdersFrame.setVisible(true);
            }
        });

        downloadOrderHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                downloadOrderHistoryToCSV();
            }
        });
    }
  private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setForeground(Color.WHITE);
        button.setBackground(Color.BLACK);
        button.setFont(new Font("Arial", Font.PLAIN, 16)); // Set a smaller font
        return button;
    }
    private void downloadOrderHistoryToCSV() {
        try {
            // Create a FileWriter to write to a CSV file
            FileWriter csvWriter = new FileWriter("orderhistorycsvs/order_history.csv");

            // Write the CSV header
            csvWriter.append("Order ID,Product Name,Quantity,Status\n");

            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM orders"
            );

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int orderId = resultSet.getInt("order_id");
                String productName = resultSet.getString("product_name");
                int quantity = resultSet.getInt("quantity");
                String status = resultSet.getString("status");

                // Write order data to the CSV file
                csvWriter.append(orderId + "," + productName + "," + quantity + "," + status + "\n");
            }

            csvWriter.flush();
            csvWriter.close();

            JOptionPane.showMessageDialog(this, "Order history downloaded to 'order_history.csv' successfully.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error creating or writing to the CSV file: " + ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }
 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Connection connection;
                try {
                    connection = DatabaseManager.getConnection();
                    if (connection != null) {
                        new DashboardFrame(connection).setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Database connection failed.");
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
                }
            }
        });
    }
}